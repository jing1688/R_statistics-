# R 統計學教室

可直接部署至 GitHub Pages 的 R 語言統計學教學網站。

## 專案結構

```text
r-statistics-tutorial/
├─ index.html
├─ .nojekyll
├─ README.md
├─ assets/
│  ├─ css/style.css
│  └─ js/site.js
└─ chapters/
   ├─ ch01.html
   ├─ ch02.html
   ├─ ...
   └─ ch13.html
```

## 部署

將所有檔案放在 repository 根目錄，執行：

```bash
git add .
git commit -m "Create R statistics tutorial website"
git push
```

在 GitHub 設定：

```text
Settings → Pages
Source: Deploy from a branch
Branch: main
Folder: / (root)
```

若帳號是 `jing1688`，repository 名稱是 `r-statistics-tutorial`，網址為：

```text
https://jing1688.github.io/r-statistics-tutorial/
```
